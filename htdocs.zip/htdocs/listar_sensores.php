<?php
include "db.php";

$sql = "SELECT * FROM sensores ORDER BY id DESC";

$result = $conn->query($sql);

$sensores = [];

while($row = $result->fetch_assoc()){
    $sensores[] = $row;
}

header('Content-Type: application/json');
echo json_encode($sensores);
?>