<?php
require_once "config.php";

$erro = "";
$sucesso = "";

if (isset($_GET["token"])) {

    $token = $_GET["token"];

    $sql = "SELECT id
            FROM utilizadores
            WHERE reset_token = ?
            AND reset_expira > NOW()
            LIMIT 1";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $token);
    $stmt->execute();

    $resultado = $stmt->get_result();

    if ($resultado->num_rows === 1) {

        $user = $resultado->fetch_assoc();

        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            $nova = $_POST["password"];

            if (!empty($nova)) {

                $hash = password_hash($nova, PASSWORD_DEFAULT);

                $update = "UPDATE utilizadores
                           SET password = ?,
                               reset_token = NULL,
                               reset_expira = NULL
                           WHERE id = ?";

                $stmt2 = $conn->prepare($update);

                $stmt2->bind_param(
                    "si",
                    $hash,
                    $user["id"]
                );

                $stmt2->execute();

                $sucesso = "Password alterada com sucesso!";
            }
        }

    } else {

        $erro = "Token inválido ou expirado!";
    }

} else {

    $erro = "Token inválido!";
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>Nova Password</title>
</head>
<body>

<h2>Nova Password</h2>

<?php echo $erro; ?>
<?php echo $sucesso; ?>

<form method="POST">

<input type="password"
       name="password"
       placeholder="Nova password"
       required>

<button type="submit">
Guardar
</button>

</form>

</body>
</html>