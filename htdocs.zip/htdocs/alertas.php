<?php
session_start();
require_once "config.php";

/* =========================================
   PROTEÇÃO
========================================= */

if (!isset($_SESSION["id"])) {
    header("Location: login.php");
    exit();
}

/* =========================================
   ENVIAR BOMBEIROS
========================================= */

$notificacao = "";

if(isset($_POST["enviar_bombeiros"])){

    $id_alerta = intval($_POST["id_alerta"]);

    $sql = "
    UPDATE alertas
    SET estado='bombeiros_enviados'
    WHERE id='$id_alerta'
    ";

    if($conn->query($sql) === TRUE){

        $notificacao = "
        <div class='notificacao sucesso'>
            🚒 Bombeiros enviados com sucesso.
        </div>
        ";

    } else {

        $notificacao = "
        <div class='notificacao erro'>
            ❌ Erro ao enviar bombeiros.
        </div>
        ";
    }
}

/* =========================================
   BUSCAR ALERTAS
========================================= */

$sql = "
SELECT *
FROM alertas
ORDER BY data_alerta DESC
";

$resultado = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="pt">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>IGNISSHIELD - Centro de Controlo</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>

/* =========================================
   BASE
========================================= */

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial, Helvetica, sans-serif;
}

body{
    background:#050505;
    color:white;
    padding:25px;
}

/* =========================================
   TOPO
========================================= */

.topbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:35px;
    flex-wrap:wrap;
    gap:20px;
}

.logo-area h1{
    font-size:42px;
}

.logo-area p{
    color:#999;
    margin-top:5px;
}

/* =========================================
   AÇÕES TOPO
========================================= */

.top-actions{
    display:flex;
    gap:15px;
    align-items:center;
    flex-wrap:wrap;
}

.btn-home,
.btn-logout{
    text-decoration:none;
    padding:14px 18px;
    border-radius:14px;
    font-weight:bold;
    display:flex;
    align-items:center;
    gap:10px;
    transition:0.3s;
}

.btn-home{
    background:#ff6600;
    color:white;
}

.btn-home:hover{
    background:#ff8533;
}

.btn-logout{
    background:#222;
    color:white;
    border:1px solid #333;
}

.btn-logout:hover{
    background:#333;
}

.user-box{
    background:#151515;
    border:1px solid #2b2b2b;
    padding:14px 22px;
    border-radius:14px;
}

/* =========================================
   NOTIFICAÇÕES
========================================= */

.notificacao{
    padding:18px;
    border-radius:14px;
    margin-bottom:25px;
    font-weight:bold;
}

.sucesso{
    background:#00381d;
    color:#00ff88;
    border:1px solid #00ff88;
}

.erro{
    background:#3d0000;
    color:#ff4d4d;
    border:1px solid red;
}

/* =========================================
   GRID
========================================= */

.grid{
    display:grid;
    grid-template-columns:repeat(auto-fit, minmax(450px, 1fr));
    gap:25px;
}

/* =========================================
   CARD
========================================= */

.card{
    background:linear-gradient(145deg,#111,#1b1b1b);
    border:1px solid #262626;
    border-left:8px solid #ff6600;
    border-radius:24px;
    padding:28px;
    position:relative;
    overflow:hidden;
    transition:0.3s;
}

.card:hover{
    transform:translateY(-5px);
    border-color:#ff6600;
}

.card::after{
    content:'';
    position:absolute;
    width:400px;
    height:400px;
    background:rgba(255,102,0,0.08);
    border-radius:50%;
    top:-200px;
    right:-200px;
}

/* =========================================
   HEADER CARD
========================================= */

.card-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:25px;
}

.card-header h2{
    font-size:28px;
}

.fire-icon{
    width:75px;
    height:75px;
    background:#ff6600;
    border-radius:20px;
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:30px;
}

/* =========================================
   INFO
========================================= */

.info{
    margin-bottom:15px;
    color:#ddd;
    font-size:16px;
}

.info i{
    color:#ff6600;
    width:28px;
}

/* =========================================
   ESTADO
========================================= */

.estado{
    display:inline-block;
    margin-top:10px;
    padding:10px 16px;
    border-radius:12px;
    font-weight:bold;
    font-size:14px;
}

.baixo{
    background:#003b1d;
    color:#00ff88;
}

.medio{
    background:#3d2a00;
    color:#ffb300;
}

.critico{
    background:#3d0000;
    color:#ff4d4d;
}

/* =========================================
   MENSAGEM
========================================= */

.msg{
    background:#202020;
    border:1px solid #2e2e2e;
    padding:18px;
    border-radius:14px;
    margin-top:20px;
    line-height:1.6;
}

/* =========================================
   BOTÕES
========================================= */

.botoes{
    display:flex;
    gap:15px;
    margin-top:25px;
    flex-wrap:wrap;
}

.btn{
    border:none;
    padding:14px 18px;
    border-radius:14px;
    cursor:pointer;
    transition:0.3s;
    font-weight:bold;
    font-size:15px;
}

.btn-bombeiros{
    background:#ff6600;
    color:white;
}

.btn-bombeiros:hover{
    background:#ff8533;
}

.btn-monitorizar{
    background:#242424;
    color:white;
}

.btn-monitorizar:hover{
    background:#333;
}

/* =========================================
   MONITORIZAÇÃO
========================================= */

.monitorizacao{
    margin-top:25px;
    background:#181818;
    border:1px solid #2d2d2d;
    border-radius:18px;
    padding:20px;
    display:none;
    animation:fadeIn 0.4s ease;
}

.monitorizacao h3{
    margin-bottom:20px;
    color:#ff6600;
}

.graficos{
    display:flex;
    flex-direction:column;
    gap:20px;
}

.grafico-box{
    background:#111;
    padding:15px;
    border-radius:14px;
}

.grafico-topo{
    display:flex;
    justify-content:space-between;
    margin-bottom:10px;
    font-weight:bold;
}

.barra{
    width:100%;
    height:18px;
    background:#2b2b2b;
    border-radius:30px;
    overflow:hidden;
}

.progresso{
    height:100%;
    width:0%;
    border-radius:30px;
    transition:1s;
}

.temperatura-bar{
    background:linear-gradient(90deg,#ff3300,#ff9900);
}

.humidade-bar{
    background:linear-gradient(90deg,#00bfff,#0077ff);
}

.vento-bar{
    background:linear-gradient(90deg,#cccccc,#ffffff);
}

/* =========================================
   ANIMAÇÕES
========================================= */

@keyframes fadeIn{

    from{
        opacity:0;
        transform:translateY(10px);
    }

    to{
        opacity:1;
        transform:translateY(0);
    }
}

/* =========================================
   RESPONSIVO
========================================= */

@media(max-width:900px){

    .grid{
        grid-template-columns:1fr;
    }

    .topbar{
        flex-direction:column;
        align-items:flex-start;
    }
}

</style>

</head>

<body>

<!-- =========================================
     TOPO
========================================= -->

<div class="topbar">

    <div class="logo-area">

        <h1>🔥 IGNISSHIELD</h1>

        <p>Centro Inteligente de Monitorização de Incêndios</p>

    </div>

    <div class="top-actions">

        <!-- INÍCIO -->
        <a href="dashboard.php" class="btn-home">

            <i class="fa-solid fa-house"></i>
            Página Inicial

        </a>

        <!-- SAIR -->
        <a href="logout.php" class="btn-logout">

            <i class="fa-solid fa-right-from-bracket"></i>
            Sair

        </a>

        <!-- USER -->
        <div class="user-box">

            👤 <?php echo htmlspecialchars($_SESSION["utilizador"]); ?>

        </div>

    </div>

</div>

<!-- NOTIFICAÇÃO -->
<?php echo $notificacao; ?>

<!-- =========================================
     GRID
========================================= -->

<div class="grid">

<?php

if($resultado->num_rows > 0){

    while($row = $resultado->fetch_assoc()){

?>

<!-- CARD -->

<div class="card">

    <!-- HEADER -->
    <div class="card-header">

        <h2>
            🔥 Zona <?php echo htmlspecialchars($row["sensor"]); ?>
        </h2>

        <div class="fire-icon">
            <i class="fa-solid fa-fire-flame-curved"></i>
        </div>

    </div>

    <!-- LOCALIZAÇÃO -->
    <div class="info">
        <i class="fa-solid fa-location-dot"></i>
        <?php echo htmlspecialchars($row["localizacao"]); ?>
    </div>

    <!-- RUA -->
    <div class="info">
        <i class="fa-solid fa-road"></i>
        Rua: <?php echo htmlspecialchars($row["rua"]); ?>
    </div>

    <!-- PORTA -->
    <div class="info">
        <i class="fa-solid fa-house"></i>
        Nº Porta: <?php echo htmlspecialchars($row["porta"]); ?>
    </div>

    <!-- TIPO -->
    <div class="info">
        <i class="fa-solid fa-triangle-exclamation"></i>
        Ocorrência: <?php echo htmlspecialchars($row["tipo"]); ?>
    </div>

    <!-- DATA -->
    <div class="info">
        <i class="fa-solid fa-clock"></i>
        <?php echo $row["data_alerta"]; ?>
    </div>

    <!-- TEMPERATURA -->
    <div class="info">
        <i class="fa-solid fa-temperature-high"></i>
        Temperatura:
        <span class="temperatura"></span>°C
    </div>

    <!-- HUMIDADE -->
    <div class="info">
        <i class="fa-solid fa-droplet"></i>
        Humidade:
        <span class="humidade"></span>%
    </div>

    <!-- VENTO -->
    <div class="info">
        <i class="fa-solid fa-wind"></i>
        Vento:
        <span class="vento"></span> km/h
    </div>

    <!-- ESTADO -->
    <div class="estado estado-risco">
        MONITORIZAR
    </div>

    <!-- MENSAGEM -->
    <div class="msg">
        <?php echo htmlspecialchars($row["mensagem"]); ?>
    </div>

    <!-- BOTÕES -->
    <div class="botoes">

        <!-- ENVIAR BOMBEIROS -->
        <form method="POST">

            <input type="hidden"
            name="id_alerta"
            value="<?php echo $row["id"]; ?>">

            <button type="submit"
            name="enviar_bombeiros"
            class="btn btn-bombeiros">

                🚒 Enviar Bombeiros

            </button>

        </form>

        <!-- MONITORIZAR -->
        <button class="btn btn-monitorizar"
        onclick="abrirMonitorizacao(this)">

            📡 Monitorizar

        </button>

    </div>

    <!-- MONITORIZAÇÃO -->
    <div class="monitorizacao">

        <h3>📊 Monitorização em Tempo Real</h3>

        <div class="graficos">

            <!-- TEMPERATURA -->
            <div class="grafico-box">

                <div class="grafico-topo">

                    <span>🔥 Temperatura</span>

                    <span class="valor-temp">0°C</span>

                </div>

                <div class="barra">

                    <div class="progresso temperatura-bar"></div>

                </div>

            </div>

            <!-- HUMIDADE -->
            <div class="grafico-box">

                <div class="grafico-topo">

                    <span>💧 Humidade</span>

                    <span class="valor-hum">0%</span>

                </div>

                <div class="barra">

                    <div class="progresso humidade-bar"></div>

                </div>

            </div>

            <!-- VENTO -->
            <div class="grafico-box">

                <div class="grafico-topo">

                    <span>💨 Vento</span>

                    <span class="valor-vento">0 km/h</span>

                </div>

                <div class="barra">

                    <div class="progresso vento-bar"></div>

                </div>

            </div>

        </div>

    </div>

</div>

<?php

    }

} else {

    echo "
    <div class='card'>

        <h2>Sem Alertas</h2>

        <div class='msg'>
            Não existem incêndios ativos neste momento.
        </div>

    </div>
    ";
}

?>

</div>

<!-- =========================================
     SCRIPT
========================================= -->

<script>

/* =========================================
   ABRIR MONITORIZAÇÃO
========================================= */

function abrirMonitorizacao(botao){

    let card = botao.closest(".card");

    let painel = card.querySelector(".monitorizacao");

    if(painel.style.display == "block"){

        painel.style.display = "none";

    } else {

        painel.style.display = "block";
    }
}

/* =========================================
   TEMPO REAL
========================================= */

function atualizarSensores(){

    document.querySelectorAll(".card").forEach(card => {

        let temperatura =
        Math.floor(Math.random() * (55 - 30) + 30);

        let humidade =
        Math.floor(Math.random() * (90 - 10) + 10);

        let vento =
        Math.floor(Math.random() * (70 - 5) + 5);

        /* TEXTO */

        card.querySelector(".temperatura").innerHTML =
        temperatura;

        card.querySelector(".humidade").innerHTML =
        humidade;

        card.querySelector(".vento").innerHTML =
        vento;

        /* GRÁFICOS */

        card.querySelector(".temperatura-bar").style.width =
        temperatura + "%";

        card.querySelector(".humidade-bar").style.width =
        humidade + "%";

        card.querySelector(".vento-bar").style.width =
        vento + "%";

        /* VALORES */

        card.querySelector(".valor-temp").innerHTML =
        temperatura + "°C";

        card.querySelector(".valor-hum").innerHTML =
        humidade + "%";

        card.querySelector(".valor-vento").innerHTML =
        vento + " km/h";

        /* ESTADO */

        let estado = "BAIXO";
        let classe = "baixo";

        if(temperatura >= 45 || vento >= 50){

            estado = "CRÍTICO";
            classe = "critico";

        }

        else if(temperatura >= 38){

            estado = "MÉDIO";
            classe = "medio";
        }

        let estadoBox =
        card.querySelector(".estado-risco");

        estadoBox.innerHTML = estado;

        estadoBox.classList.remove(
            "baixo",
            "medio",
            "critico"
        );

        estadoBox.classList.add(classe);

    });

}

/* EXECUTAR */
atualizarSensores();

/* TEMPO REAL */
setInterval(atualizarSensores, 2000);

</script>

</body>
</html>