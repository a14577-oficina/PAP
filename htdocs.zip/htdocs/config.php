<?php

/* =========================================
   CONFIGURAÇÃO DA BASE DE DADOS
========================================= */
/*
$host = "sql101.infinityfree.com";
$user = "root";
$pass = "root";
$db   = "if0_42014818_XXX";
*/

$host = "sql101.infinityfree.com";
$user = "if0_42014818";
$pass = "qL4IqTgcLTmFSd5";
$db   = "if0_42014818_ignisshield";

/* =========================================
   LIGAÇÃO À BASE DE DADOS
========================================= */

$conn = new mysqli($host, $user, $pass, $db);

/* =========================================
   VERIFICAR LIGAÇÃO
========================================= */

if ($conn->connect_error) {
    die("Erro na ligação à base de dados: " . $conn->connect_error);
}

/* =========================================
   DEFINIR UTF-8
========================================= */

$conn->set_charset("utf8");

?>