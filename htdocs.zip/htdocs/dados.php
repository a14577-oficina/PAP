<?php

$temp = $_POST['temperatura'];

file_put_contents(
    "dados.txt",
    date("Y-m-d H:i:s") . " - " . $temp . PHP_EOL,
    FILE_APPEND
);

echo "OK";

?>