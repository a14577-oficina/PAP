<?php
session_start();

/* REMOVER TODAS AS SESSÕES */
$_SESSION = [];

/* DESTRUIR SESSÃO */
session_destroy();

/* REDIRECIONAR PARA LOGIN */
header("Location: index.php");
exit;
?>