<?php
include "db.php";

$id = $_POST['id'];
$estado = $_POST['estado'];
$valor = $_POST['valor'];

$sql = "UPDATE sensores 
SET estado=?, valor=?, ultima_leitura=NOW()
WHERE id=?";

$stmt = $conn->prepare($sql);

$stmt->bind_param(
    "ssi",
    $estado,
    $valor,
    $id
);

if($stmt->execute()){
    echo "Sensor atualizado";
}else{
    echo "Erro";
}
?> 