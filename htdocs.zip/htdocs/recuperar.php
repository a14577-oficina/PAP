<?php
session_start();
require_once "config.php";

$mensagem = "";
$mostrarNovaPassword = false;
$email = "";

/* =========================================
   VERIFICAR EMAIL
========================================= */

if (isset($_POST["verificar_email"])) {

    $email = trim($_POST["email"]);

    if (!empty($email)) {

        $sql = "SELECT * FROM utilizadores
                WHERE email = ?
                LIMIT 1";

        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            die("Erro SQL: " . $conn->error);
        }

        $stmt->bind_param("s", $email);
        $stmt->execute();

        $resultado = $stmt->get_result();

        if ($resultado->num_rows === 1) {

            $mostrarNovaPassword = true;

        } else {

            $mensagem = "Email não encontrado!";
        }

    } else {

        $mensagem = "Introduza o email!";
    }
}

/* =========================================
   ALTERAR PASSWORD
========================================= */

if (isset($_POST["alterar_password"])) {

    $email = trim($_POST["email"]);
    $novaPassword = $_POST["nova_password"];

    if (!empty($novaPassword)) {

        /* HASH DA PASSWORD */
        $passwordHash = password_hash(
            $novaPassword,
            PASSWORD_DEFAULT
        );

        $sql = "UPDATE utilizadores
                SET password = ?
                WHERE email = ?";

        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            die("Erro SQL: " . $conn->error);
        }

        $stmt->bind_param(
            "ss",
            $passwordHash,
            $email
        );

        if ($stmt->execute()) {

            $mensagem = "Password alterada com sucesso!";

        } else {

            $mensagem = "Erro ao alterar password!";
        }

    } else {

        $mensagem = "Introduza a nova password!";
        $mostrarNovaPassword = true;
    }
}
?>

<!DOCTYPE html>
<html lang="pt">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Recuperar Password</title>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial, Helvetica, sans-serif;
}

body{
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:#000;
    overflow:hidden;
    position:relative;
}

/* FUNDO */
body::before{
    content:'';
    position:absolute;
    width:700px;
    height:700px;
    background:red;
    border-radius:50%;
    filter:blur(180px);
    opacity:0.18;
    z-index:0;
}

/* BOX */
.box{
    position:relative;
    z-index:2;
    width:420px;
    background:#111;
    border:2px solid red;
    border-radius:25px;
    padding:40px;
    text-align:center;
    box-shadow:0 0 35px rgba(255,0,0,0.5);
}

/* TITULO */
.titulo{
    color:white;
    font-size:28px;
    font-weight:bold;
    margin-bottom:25px;
    letter-spacing:2px;
}

/* INPUTS */
.input-box{
    margin-bottom:20px;
}

.input-box input{
    width:100%;
    padding:15px;
    background:#1a1a1a;
    border:1px solid #333;
    border-radius:12px;
    color:white;
    font-size:16px;
    outline:none;
    transition:0.3s;
}

.input-box input:focus{
    border-color:red;
    box-shadow:0 0 12px red;
}

/* BOTÃO */
.btn{
    width:100%;
    padding:15px;
    background:red;
    border:none;
    border-radius:12px;
    color:white;
    font-size:18px;
    font-weight:bold;
    cursor:pointer;
    transition:0.3s;
}

.btn:hover{
    background:#cc0000;
    transform:scale(1.03);
}

/* MENSAGEM */
.msg{
    background:#330000;
    border:1px solid red;
    color:#04d63c;
    padding:12px;
    border-radius:10px;
    margin-bottom:20px;
}

/* BOTÃO VOLTAR LOGIN */
.voltar-login{
    display:block;
    text-align:center;
    margin-top:15px;
    padding:12px;
    background:#222;
    border:1px solid red;
    border-radius:10px;
    color:white;
    text-decoration:none;
    transition:0.3s;
}

.voltar-login:hover{
    background:red;
    box-shadow:0 0 10px red;
}

/* FOOTER */
.footer{
    margin-top:20px;
    color:#888;
    font-size:14px;
}

</style>

</head>

<body>

<div class="box">

    <div class="titulo">
        RECUPERAR PASSWORD
    </div>

    <!-- MENSAGENS -->
    <?php if(!empty($mensagem)) { ?>

        <div class="msg">
            <?php echo $mensagem; ?>
        </div>

    <?php } ?>

    <?php if(!$mostrarNovaPassword) { ?>

        <!-- VERIFICAR EMAIL -->
        <form method="POST">

            <div class="input-box">

                <input type="email"
                       name="email"
                       placeholder="Introduza o Email"
                       required>

            </div>

            <button type="submit"
                    name="verificar_email"
                    class="btn">

                Verificar Email

            </button>

        </form>

        <!-- VOLTAR LOGIN -->
        <a href="index.php"
           class="voltar-login">

            Voltar ao Login

        </a>

    <?php } else { ?>

        <!-- NOVA PASSWORD -->
        <form method="POST">

            <input type="hidden"
                   name="email"
                   value="<?php echo $email; ?>">

            <div class="input-box">

                <input type="password"
                       name="nova_password"
                       placeholder="Nova Palavra-passe"
                       required>

            </div>

            <button type="submit"
                    name="alterar_password"
                    class="btn">

                Guardar Nova Password

            </button>

        </form>

        <!-- VOLTAR LOGIN -->
        <a href="index.php"
           class="voltar-login">

            Voltar ao Login

        </a>

    <?php } ?>

    <div class="footer">
        IGNISSHIELD • Sensor de Incêndio
    </div>

</div>

</body>
</html>