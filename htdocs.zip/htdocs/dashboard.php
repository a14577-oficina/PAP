<?php
session_start();

/* VERIFICAR LOGIN */
if(!isset($_SESSION["id"])){
    header("Location: login.php");
    exit();
}

include "config.php";

/* =========================
   DASHBOARD QUERIES
========================= */

// TOTAL SENSORES
$resultSensores = $conn->query("SELECT COUNT(*) AS total FROM sensores");
$totalSensores = $resultSensores->fetch_assoc()["total"];

// TOTAL UTILIZADORES
$resultUsers = $conn->query("SELECT COUNT(*) AS total FROM utilizadores");
$totalUsers = $resultUsers->fetch_assoc()["total"];

// TOTAL ALERTAS (ativos)
$resultAlertas = $conn->query("SELECT COUNT(*) AS total FROM alertas WHERE estado='ativo'");
$totalAlertas = $resultAlertas->fetch_assoc()["total"];

?>

<!DOCTYPE html>
<html lang="pt">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>IGNISSHIELD Dashboard</title>

<!-- ICONS -->
<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial, Helvetica, sans-serif;
}

body{
    display:flex;
    background:#0d0d0d;
    color:white;
    min-height:100vh;
}

/* =========================================
   MENU LATERAL
========================================= */

.sidebar{
    width:260px;
    background:#111;
    border-right:2px solid red;
    padding:20px;
    display:flex;
    flex-direction:column;
}

.logo{
    width:180px;
    margin:0 auto 30px auto;
}

.menu-title{
    color:#777;
    margin-bottom:15px;
    font-size:14px;
    text-transform:uppercase;
}

.menu{
    list-style:none;
}

.menu li{
    margin-bottom:10px;
}

.menu a{
    display:flex;
    align-items:center;
    gap:15px;
    text-decoration:none;
    color:white;
    padding:14px;
    border-radius:12px;
    transition:0.3s;
    background:#1a1a1a;
}

.menu a:hover{
    background:red;
    transform:translateX(5px);
}

/* MENU ATIVO */

.menu a.active{
    background:red;
}

/* =========================================
   CONTEÚDO
========================================= */

.main{
    flex:1;
    padding:30px;
}

/* TOPO */

.topbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:30px;
}

.topbar h1{
    font-size:32px;
}

.user{
    background:#1a1a1a;
    padding:12px 20px;
    border-radius:12px;
    border:1px solid #333;
}

/* =========================================
   CARDS
========================================= */

.cards{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
    gap:20px;
    margin-bottom:40px;
}

.card{
    background:#161616;
    padding:25px;
    border-radius:20px;
    border:1px solid #222;
    transition:0.3s;
}

.card:hover{
    border-color:red;
    transform:translateY(-5px);
}

.card i{
    font-size:40px;
    color:red;
    margin-bottom:15px;
}

.card h2{
    font-size:20px;
    margin-bottom:10px;
}

.card p{
    color:#aaa;
    font-size:15px;
}

/* =========================================
   TABELA
========================================= */

.table-box{
    background:#161616;
    padding:25px;
    border-radius:20px;
    border:1px solid #222;
}

.table-box h2{
    margin-bottom:20px;
}

table{
    width:100%;
    border-collapse:collapse;
}

table th{
    background:red;
    color:white;
    padding:15px;
    text-align:left;
}

table td{
    padding:15px;
    border-bottom:1px solid #333;
}

.status{
    padding:6px 12px;
    border-radius:8px;
    font-size:13px;
    font-weight:bold;
}

.online{
    background:#003300;
    color:#00ff00;
}

.alerta{
    background:#330000;
    color:#ff4d4d;
}

/* =========================================
   RESPONSIVO
========================================= */

@media(max-width:900px){

    .sidebar{
        width:90px;
    }

    .sidebar .text{
        display:none;
    }

    .logo{
        width:60px;
    }

    .menu a{
        justify-content:center;
    }

    .topbar{
        flex-direction:column;
        gap:15px;
        align-items:flex-start;
    }

}

</style>

</head>

<body>

<!-- MENU LATERAL -->
<div class="sidebar">

    <img src="logo.png" class="logo">

    <div class="menu-title">
        MENU
    </div>

    <ul class="menu">

        <li>
            <a href="dashboard.php" class="active">
                <i class="fa-solid fa-gauge"></i>
                <span class="text">Dashboard</span>
            </a>
        </li>

        <li>
            <a href="sensores.php">
                <i class="fa-solid fa-fire"></i>
                <span class="text">Sensores</span>
            </a>
        </li>

        <?php if(isset($_SESSION["tipo"]) && $_SESSION["tipo"] == "admin") { ?>

        <li>
            <a href="utilizadores.php">
                <i class="fa-solid fa-users"></i>
                <span class="text">Utilizadores</span>
            </a>
        </li>

        <?php } ?>

        <li>
            <a href="alertas.php">
                <i class="fa-solid fa-triangle-exclamation"></i>
                <span class="text">Alertas</span>
            </a>
        </li>

        <li>
            <a href="logout.php">
                <i class="fa-solid fa-right-from-bracket"></i>
                <span class="text">Logout</span>
            </a>
        </li>

    </ul>

</div>

<!-- CONTEÚDO -->
<div class="main">

    <div class="topbar">

        <h1>
            Dashboard IGNISSHIELD
        </h1>

        <div class="user">
            👤 <?php echo htmlspecialchars($_SESSION["utilizador"]); ?>
        </div>

    </div>

    <!-- CARDS -->
    <div class="cards">

        <div class="card">
            <i class="fa-solid fa-fire"></i>
            <h2><?php echo $totalSensores; ?> Sensores</h2>
            <p>Sensores ativos no sistema</p>
        </div>

        <div class="card">
            <i class="fa-solid fa-users"></i>
            <h2><?php echo $totalUsers; ?> Utilizadores</h2>
            <p>Utilizadores registados</p>
        </div>

        <div class="card">
            <i class="fa-solid fa-triangle-exclamation"></i>
            <h2><?php echo $totalAlertas; ?> Alertas</h2>
            <p>Alertas ativos no momento</p>
        </div>

    </div>

<!-- INFORMAÇÕES DO SISTEMA -->
<div class="table-box">

    <h2>Informações em Tempo Real</h2>

    <table>

        <tr>
            <th>Informação</th>
            <th>Valor</th>
        </tr>

        <tr>
            <td>Data Atual</td>
            <td id="dataAtual"></td>
        </tr>

        <tr>
            <td>Hora Atual</td>
            <td id="horaAtual"></td>
        </tr>

        <tr>
            <td>Utilizador Ligado</td>
            <td><?php echo htmlspecialchars($_SESSION["utilizador"]); ?></td>
        </tr>

        <tr>
            <td>Total de Sensores</td>
            <td><?php echo $totalSensores; ?></td>
        </tr>

        <tr>
            <td>Total de Utilizadores</td>
            <td><?php echo $totalUsers; ?></td>
        </tr>

        <tr>
            <td>Alertas Ativos</td>
            <td><?php echo $totalAlertas; ?></td>
        </tr>

        <tr>
            <td>Servidor</td>
            <td><?php echo $_SERVER['SERVER_NAME']; ?></td>
        </tr>

        <tr>
            <td>Endereço IP</td>
            <td><?php echo $_SERVER['REMOTE_ADDR']; ?></td>
        </tr>

        <tr>
            <td>Versão PHP</td>
            <td><?php echo phpversion(); ?></td>
        </tr>

        <tr>
            <td>Estado da Plataforma</td>
            <td><span class="status online">OPERACIONAL</span></td>
        </tr>

    </table>

</div>

<script>
function atualizarRelogio() {

    const agora = new Date();

    const data =
        String(agora.getDate()).padStart(2, '0') + '/' +
        String(agora.getMonth() + 1).padStart(2, '0') + '/' +
        agora.getFullYear();

    const hora =
        String(agora.getHours()).padStart(2, '0') + ':' +
        String(agora.getMinutes()).padStart(2, '0') + ':' +
        String(agora.getSeconds()).padStart(2, '0');

    document.getElementById("dataAtual").textContent = data;
    document.getElementById("horaAtual").textContent = hora;
}

atualizarRelogio();
setInterval(atualizarRelogio, 1000);
</script>