<?php
session_start();
require_once "config.php";

/* =========================================
   VERIFICAR ADMIN
========================================= */



/* =========================================
   INSERIR UTILIZADOR
========================================= */

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $utilizador = trim($_POST["utilizador"]);
    $password   = trim($_POST["password"]);
    $perfil     = trim($_POST["perfil"]);
    $ativo      = isset($_POST["ativo"]) ? 1 : 0;

    /* VALIDAR */
    if (empty($utilizador) || empty($password) || empty($perfil)) {

        $erro = "Preencha todos os campos.";

    } else {

        /* VERIFICAR SE JÁ EXISTE */
        $check = "SELECT id FROM utilizadores WHERE utilizador = ?";
        $stmtCheck = $conn->prepare($check);
        $stmtCheck->bind_param("s", $utilizador);
        $stmtCheck->execute();

        $resultado = $stmtCheck->get_result();

        if ($resultado->num_rows > 0) {

            $erro = "O utilizador já existe.";

        } else {

            /* HASH PASSWORD */
            $password_hash = password_hash($password, PASSWORD_DEFAULT);

            /* INSERIR */
            $sql = "INSERT INTO utilizadores
                    (utilizador, password_hash, perfil, ativo)
                    VALUES (?, ?, ?, ?)";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param(
                "sssi",
                $utilizador,
                $password_hash,
                $perfil,
                $ativo
            );

            if ($stmt->execute()) {
                $mensagem = "Utilizador criado com sucesso!";
            } else {
                $erro = "Erro ao criar utilizador.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Criar Utilizador</title>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial;
}

body{
    background:#0a0a0a;
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}

.container{
    width:450px;
    background:#111;
    border:2px solid red;
    border-radius:20px;
    padding:40px;
    box-shadow:0 0 30px rgba(255,0,0,0.4);
}

h1{
    color:white;
    text-align:center;
    margin-bottom:30px;
}

.input-box{
    margin-bottom:20px;
}

.input-box label{
    display:block;
    color:#ccc;
    margin-bottom:8px;
}

.input-box input,
.input-box select{
    width:100%;
    padding:14px;
    border:none;
    border-radius:10px;
    background:#1a1a1a;
    color:white;
    font-size:15px;
}

.input-box input:focus,
.input-box select:focus{
    outline:none;
    border:1px solid red;
    box-shadow:0 0 10px red;
}

.checkbox{
    color:white;
    margin-bottom:20px;
}

button{
    width:100%;
    padding:15px;
    background:red;
    border:none;
    border-radius:12px;
    color:white;
    font-size:16px;
    font-weight:bold;
    cursor:pointer;
}

button:hover{
    background:#cc0000;
}

.msg{
    background:#003300;
    color:#66ff66;
    padding:12px;
    border-radius:10px;
    margin-bottom:20px;
}

.erro{
    background:#330000;
    color:#ff6666;
    padding:12px;
    border-radius:10px;
    margin-bottom:20px;
}

</style>

</head>
<body>

<div class="container">

    <h1>NOVO UTILIZADOR</h1>

    <?php if($mensagem != "") { ?>
        <div class="msg">
            <?php echo $mensagem; ?>
        </div>
    <?php } ?>

    <?php if($erro != "") { ?>
        <div class="erro">
            <?php echo $erro; ?>
        </div>
    <?php } ?>

    <form method="POST">

        <div class="input-box">
            <label>Utilizador</label>
            <input type="text"
                   name="utilizador"
                   required>
        </div>

        <div class="input-box">
            <label>Palavra-passe</label>
            <input type="password"
                   name="password"
                   required>
        </div>

        <div class="input-box">
            <label>Perfil</label>

            <select name="perfil" required>
                <option value="">Selecionar</option>
                <option value="admin">Administrador</option>
                <option value="tecnico">Técnico</option>
                <option value="operador">Operador</option>
                <option value="user">Utilizador</option>
            </select>
        </div>

        <div class="checkbox">
            <input type="checkbox"
                   name="ativo"
                   checked>

            Utilizador ativo
        </div>

        <button type="submit">
            CRIAR UTILIZADOR
        </button>

    </form>

</div>

</body>
</html>