<?php
session_start();
require_once "config.php";

$erro = "";

/* =========================================
   LOGIN
========================================= */

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $utilizador_input = trim($_POST["utilizador"]);
    $password         = $_POST["password"];

    if (!empty($utilizador_input) && !empty($password)) {

        $sql = "SELECT * FROM utilizadores
                WHERE utilizador = ?
                AND ativo = 1
                LIMIT 1";

        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            die("Erro SQL: " . $conn->error);
        }

        $stmt->bind_param("s", $utilizador_input);
        $stmt->execute();

        $resultado = $stmt->get_result();

        if ($resultado->num_rows === 1) {

            $utilizador = $resultado->fetch_assoc();

            /* VERIFICAR PASSWORD */
            if (password_verify(
                $password,
                $utilizador["password"]
            )) {

                session_regenerate_id(true);

                /* SESSÕES */
                $_SESSION["id"]         = $utilizador["id"];
                $_SESSION["utilizador"] = $utilizador["utilizador"];
                $_SESSION["perfil"]     = $utilizador["perfil"];
                $_SESSION["email"]      = $utilizador["email"];
                $_SESSION["zona"]       = $utilizador["zona"];

                /* NOVA SESSÃO DE PERMISSÃO */
                $_SESSION["tipo"] = $utilizador["perfil"];

                /* ATUALIZAR LOGIN */
                $update = "UPDATE utilizadores
                           SET ultimo_login = NOW()
                           WHERE id = ?";

                $stmt2 = $conn->prepare($update);
                $stmt2->bind_param("i", $utilizador["id"]);
                $stmt2->execute();

                header("Location: dashboard.php");
                exit;

            } else {
                $erro = "Palavra-passe incorreta!";
            }

        } else {
            $erro = "Utilizador não encontrado!";
        }

    } else {
        $erro = "Preencha todos os campos!";
    }
}
?>

<!DOCTYPE html>
<html lang="pt">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>IGNISSHIELD LOGIN</title>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial, Helvetica, sans-serif;
}

body{
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:#000;
    overflow:hidden;
    position:relative;
}

body::before{
    content:'';
    position:absolute;
    width:700px;
    height:700px;
    background:red;
    border-radius:50%;
    filter:blur(180px);
    opacity:0.18;
    z-index:0;
}

.login-box{
    position:relative;
    z-index:2;
    width:430px;
    background:#111;
    border:2px solid red;
    border-radius:25px;
    padding:40px;
    text-align:center;
    box-shadow:0 0 35px rgba(255,0,0,0.5);
}

.logo{
    width:280px;
    margin-bottom:20px;
}

.titulo{
    color:white;
    font-size:28px;
    font-weight:bold;
    margin-bottom:25px;
    letter-spacing:2px;
}

.input-box{
    margin-bottom:20px;
}

.input-box input{
    width:100%;
    padding:15px;
    background:#1a1a1a;
    border:1px solid #333;
    border-radius:12px;
    color:white;
    font-size:16px;
    outline:none;
    transition:0.3s;
}

.input-box input:focus{
    border-color:red;
    box-shadow:0 0 12px red;
}

.btn{
    width:100%;
    padding:15px;
    background:red;
    border:none;
    border-radius:12px;
    color:white;
    font-size:18px;
    font-weight:bold;
    cursor:pointer;
    transition:0.3s;
}

.btn:hover{
    background:#cc0000;
    transform:scale(1.03);
}

.erro{
    background:#330000;
    border:1px solid red;
    color:#ff6666;
    padding:12px;
    border-radius:10px;
    margin-bottom:20px;
}

.recuperar{
    margin-top:15px;
}

.recuperar a{
    color:#ff4444;
    text-decoration:none;
    font-size:14px;
    transition:0.3s;
}

.recuperar a:hover{
    color:#ff7777;
    text-shadow:0 0 8px red;
}

.footer{
    margin-top:20px;
    color:#888;
    font-size:14px;
}

</style>

</head>

<body>

<div class="login-box">

    <img src="logo.png" alt="IGNISSHIELD" class="logo">

    <div class="titulo">LOGIN</div>

    <?php if(!empty($erro)) { ?>
        <div class="erro">
            <?php echo $erro; ?>
        </div>
    <?php } ?>

    <form method="POST">

        <div class="input-box">
            <input type="text"
                   name="utilizador"
                   placeholder="Utilizador"
                   required>
        </div>

        <div class="input-box">
            <input type="password"
                   name="password"
                   placeholder="Palavra-passe"
                   required>
        </div>

        <button type="submit" class="btn">ENTRAR</button>

    </form>

    <div class="recuperar">
        <a href="recuperar.php">Esqueceu-se da palavra-passe?</a>
    </div>

    <div class="footer">
        IGNISSHIELD • Sensor de Incêndio
    </div>

</div>

</body>
</html>