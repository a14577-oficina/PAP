<?php
require_once "config.php";

$chave = $_POST["chave"] ?? "";

/* CHAVE DE SEGURANÇA */
if($chave !== "IGNISSHIELD2024"){
    http_response_code(403);
    echo "Acesso negado";
    exit();
}

$id_sensor = intval($_POST["id_sensor"] ?? 0);
$fogo      = intval($_POST["fogo"] ?? 0); // 1 = fogo detetado, 0 = normal

if($id_sensor <= 0){
    echo "ID inválido";
    exit();
}

if($fogo == 1){

    /* ATUALIZAR SENSOR PARA ALERTA */
    $stmt = $conn->prepare("
        UPDATE sensores
        SET estado = 'ALERTA'
        WHERE id = ?
    ");
    $stmt->bind_param("i", $id_sensor);
    $stmt->execute();

    /* VERIFICAR SE JÁ EXISTE ALERTA ATIVO */
    $check = $conn->prepare("
        SELECT id FROM alertas
        WHERE id_sensor = ?
        AND estado = 'ativo'
        LIMIT 1
    ");
    $check->bind_param("i", $id_sensor);
    $check->execute();
    $res = $check->get_result();

    if($res->num_rows === 0){

        /* CRIAR ALERTA */
        $stmt2 = $conn->prepare("
            INSERT INTO alertas
            (id_sensor, mensagem, estado, criado_em)
            VALUES (?, 'Fogo detetado pelo sensor Arduino!', 'ativo', NOW())
        ");
        $stmt2->bind_param("i", $id_sensor);
        $stmt2->execute();
    }

    echo "ALERTA";

} else {

    /* SENSOR NORMAL */
    $stmt = $conn->prepare("
        UPDATE sensores
        SET estado = 'Online'
        WHERE id = ?
    ");
    $stmt->bind_param("i", $id_sensor);
    $stmt->execute();

    echo "OK";
}
?>  