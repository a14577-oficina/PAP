<?php
session_start();
require_once "config.php";

/* =========================================
   PROTEÇÃO
========================================= */

if(!isset($_SESSION["id"])){
    header("Location: login.php");
    exit();
}

/* =========================================
   CRIAR SENSOR
========================================= */

$msg = "";

if(isset($_SESSION["msg"])){
    $msg = $_SESSION["msg"];
    unset($_SESSION["msg"]);
}

/* =========================================
   LÓGICA DE RESTRIÇÃO POR TIPO DE UTILIZADOR
   - admin vê tudo
   - Bombeiro_X só vê a sua localização
========================================= */

$tipoUtilizador = $_SESSION["tipo"];   // ex: "admin" ou "Bombeiro_Porto"
$localRestrita  = null;                // null = sem restrição

if($tipoUtilizador != "admin"){
    if(strpos($tipoUtilizador, "Bombeiro_") === 0){

        $sufixo = substr($tipoUtilizador, strlen("Bombeiro_"));

        // Mapa: sufixo do tipo → nome real da freguesia
        $mapaLocais = [
            "Alvalade"      => "Alvalade",
            "Benfica"       => "Benfica",
            "Lumiar"        => "Lumiar",
            "Carnide"       => "Carnide",
            "Campolide"     => "Campolide",
            "Marvila"       => "Marvila",
            "Olivais"       => "Olivais",
            "ParqueNacoes"  => "Parque das Nações",
            "SantaClara"    => "Santa Clara",
            "Ajuda"         => "Ajuda",
            "Alges"         => "Algés",
            "Amadora"       => "Amadora",
            "Sintra"        => "Sintra",
            "Cascais"       => "Cascais",
            "Oeiras"        => "Oeiras",
            "Braga"         => "Braga",
            "Porto"         => "Porto",
            "Coimbra"       => "Coimbra",
            "Faro"          => "Faro",
            "Aveiro"        => "Aveiro",
        ];

        $localRestrita = $mapaLocais[$sufixo] ?? $sufixo;
    }
}

/* BUSCAR UTILIZADORES (filtrado se necessário) */
if($localRestrita){
    // Bombeiro só vê o próprio utilizador
    $sqlUsers = "SELECT id, utilizador FROM utilizadores WHERE id = " . intval($_SESSION["id"]);
} else {
    // Admin vê todos
    $sqlUsers = "SELECT id, utilizador FROM utilizadores";
}
$resUsers = $conn->query($sqlUsers);

/* TODAS AS FREGUESIAS */
$todasFreguesias = [
    "Alvalade",
    "Benfica",
    "Lumiar",
    "Carnide",
    "Campolide",
    "Marvila",
    "Olivais",
    "Parque das Nações",
    "Santa Clara",
    "Ajuda",
    "Algés",
    "Amadora",
    "Sintra",
    "Cascais",
    "Oeiras",
    "Braga",
    "Porto",
    "Coimbra",
    "Faro",
    "Aveiro",
];

if(isset($_POST["criar"])){

    $mostrarForm = true;

    $nome          = trim($_POST["nome"]);
    $freguesia     = $_POST["freguesia"];
    $estado        = $_POST["estado"];
    $id_utilizador = intval($_POST["id_utilizador"]);

    // Segurança extra: valida que a freguesia escolhida é permitida
    if($localRestrita && $freguesia !== $localRestrita){
        $msg = "Não tem permissão para usar essa freguesia!";
    } elseif(!empty($nome) && !empty($freguesia)){

        $stmt = $conn->prepare("
            INSERT INTO sensores
            (nome, freguesia, estado, id_utilizador)
            VALUES (?, ?, ?, ?)
        ");

        $stmt->bind_param(
            "sssi",
            $nome,
            $freguesia,
            $estado,
            $id_utilizador
        );

        if($stmt->execute()){
           $_SESSION["msg"] = "Sensor criado com sucesso!";
           header("Location: sensores.php");
           exit();
        } else {
            $msg = "Erro ao criar sensor!";
        }

    } else {
        $msg = "Preencha todos os campos!";
    }
}

/* =========================================
   LISTAR SENSORES
========================================= */

$sql = "
SELECT *
FROM sensores
WHERE id_utilizador = " . $_SESSION["id"] . "
ORDER BY id DESC
";

$resultado = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="pt">

<head>

<meta charset="UTF-8">
<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Sensores - IGNISSHIELD</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>

/* =========================================
   BASE
========================================= */

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial;
}

body{
    display:flex;
    background:#0d0d0d;
    color:white;
    min-height:100vh;
}

/* SIDEBAR */

.sidebar{
    width:260px;
    background:#111;
    border-right:2px solid red;
    padding:20px;
}

.logo{
    width:180px;
    display:block;
    margin:0 auto 30px;
}

.menu{
    list-style:none;
}

.menu li{
    margin-bottom:10px;
}

.menu a{
    display:flex;
    align-items:center;
    gap:15px;
    text-decoration:none;
    color:white;
    padding:14px;
    border-radius:12px;
    background:#1a1a1a;
    transition:0.3s;
}

.menu a:hover,
.menu a.active{
    background:red;
}

/* MAIN */

.main{
    flex:1;
    padding:30px;
}

.topbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:25px;
}

.user{
    background:#1a1a1a;
    padding:12px 18px;
    border-radius:12px;
}

/* ALERT */

.alert{
    background:#1f1f1f;
    border-left:5px solid red;
    padding:15px;
    margin-bottom:20px;
    border-radius:10px;
}

/* BUTTON */

.btn-add{
    background:red;
    border:none;
    color:white;
    padding:14px 20px;
    border-radius:12px;
    cursor:pointer;
    margin-bottom:20px;
    font-size:16px;
}

/* FORM */

.form-box{
    background:#161616;
    padding:25px;
    border-radius:16px;
    margin-bottom:25px;
    display:none;
}

.form-box.active{
    display:block;
}

.form-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:20px;
}

.form-group{
    display:flex;
    flex-direction:column;
}

.form-group label{
    margin-bottom:8px;
}

.form-group input,
.form-group select{
    background:#222;
    border:1px solid #333;
    color:white;
    padding:14px;
    border-radius:10px;
}

.form-group select[disabled]{
    opacity:0.7;
    cursor:not-allowed;
}

.full{
    grid-column:1 / -1;
}

.btn-save{
    width:100%;
    background:red;
    border:none;
    color:white;
    padding:14px;
    border-radius:10px;
    cursor:pointer;
}

/* TABLE */

table{
    width:100%;
    border-collapse:collapse;
    background:#161616;
    border-radius:15px;
    overflow:hidden;
}

th{
    background:red;
    padding:15px;
    text-align:left;
}

td{
    padding:15px;
    border-bottom:1px solid #333;
}

.online{
    color:#00ff00;
    font-weight:bold;
}

.alerta{
    color:#ff4d4d;
    font-weight:bold;
}

</style>

</head>

<body>

<!-- SIDEBAR -->

<div class="sidebar">

    <img src="logo.png" class="logo">

    <ul class="menu">

        <li>
            <a href="dashboard.php">
                <i class="fa-solid fa-gauge"></i>
                Dashboard
            </a>
        </li>

        <li>
            <a href="sensores.php" class="active">
                <i class="fa-solid fa-fire"></i>
                Sensores
            </a>
        </li>

        <?php if($_SESSION["tipo"] == "admin"){ ?>

        <li>
            <a href="utilizadores.php">
                <i class="fa-solid fa-users"></i>
                Utilizadores
            </a>
        </li>

        <?php } ?>

        <li>
            <a href="logout.php">
                <i class="fa-solid fa-right-from-bracket"></i>
                Logout
            </a>
        </li>

    </ul>

</div>

<!-- MAIN -->

<div class="main">

    <div class="topbar">

        <h1>Sensores de Incêndio</h1>

        <div class="user">
            👤 <?php echo $_SESSION["utilizador"]; ?>
        </div>

    </div>

    <?php if($msg != ""){ ?>

        <div class="alert">
            <?php echo $msg; ?>
        </div>

    <?php } ?>

    <button class="btn-add"
    onclick="toggleForm()">

        <i class="fa fa-plus"></i>
        Novo Sensor

    </button>

    <!-- FORM -->

    <div class="form-box <?php echo isset($mostrarForm) && $mostrarForm ? 'active' : ''; ?>"
    id="formBox">

        <form method="POST">

            <div class="form-grid">

                <div class="form-group">

                    <label>Nome Sensor</label>

                    <input type="text"
                    name="nome"
                    placeholder="Sensor Fogo A1"
                    required>

                </div>

                <div class="form-group">

                    <label>Freguesia</label>

                    <?php if($localRestrita): ?>

                        <!-- Bombeiro: campo bloqueado, só a sua freguesia -->
                        <select name="freguesia" disabled>
                            <option value="<?= htmlspecialchars($localRestrita) ?>" selected>
                                <?= htmlspecialchars($localRestrita) ?>
                            </option>
                        </select>
                        <!-- Hidden garante envio do valor mesmo com disabled -->
                        <input type="hidden" name="freguesia" value="<?= htmlspecialchars($localRestrita) ?>">

                    <?php else: ?>

                        <!-- Admin: todas as freguesias -->
                        <select name="freguesia">
                            <?php foreach($todasFreguesias as $f): ?>
                                <option value="<?= htmlspecialchars($f) ?>">
                                    <?= htmlspecialchars($f) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>

                    <?php endif; ?>

                </div>

                <div class="form-group">

                    <label>Utilizador Responsável</label>

                    <select name="id_utilizador" <?= $localRestrita ? 'disabled' : '' ?>>

                        <?php while($u = $resUsers->fetch_assoc()){ ?>

                            <option value="<?= $u["id"] ?>" selected>
                                <?= htmlspecialchars($u["utilizador"]) ?>
                            </option>

                        <?php } ?>

                    </select>

                    <?php if($localRestrita): ?>
                        <!-- Hidden garante envio do valor mesmo com disabled -->
                        <input type="hidden" name="id_utilizador" value="<?= intval($_SESSION["id"]) ?>">
                    <?php endif; ?>

                </div>

                <div class="form-group">

                    <label>Estado</label>

                    <select name="estado">

                        <option value="Online">
                            Online
                        </option>

                        <option value="ALERTA">
                            ALERTA
                        </option>

                    </select>

                </div>

                <div class="form-group full">

                    <button type="submit"
                    name="criar"
                    class="btn-save">

                        <i class="fa fa-save"></i>
                        Guardar Sensor

                    </button>

                </div>

            </div>

        </form>

    </div>

    <!-- TABLE -->

    <table>

        <tr>
            <th>ID</th>
            <th>Sensor</th>
            <th>Freguesia</th>
            <th>Estado</th>
        </tr>

        <?php while($row = $resultado->fetch_assoc()){ ?>

        <tr>

            <td><?php echo $row["id"]; ?></td>
            <td><?php echo $row["nome"]; ?></td>
            <td><?php echo $row["freguesia"]; ?></td>

            <td>

                <?php if($row["estado"] == "Online"){ ?>

                    <span class="online">Online</span>

                <?php } else { ?>

                    <span class="alerta">ALERTA</span>

                <?php } ?>

            </td>

        </tr>

        <?php } ?>

    </table>

</div>

<script>

function toggleForm(){
    document.getElementById("formBox").classList.toggle("active");
}

</script>

</body>
</html>