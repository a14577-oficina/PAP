<?php
session_start();
require_once "config.php";

/* =========================================
   PROTEÇÃO
========================================= */

if (!isset($_SESSION["id"])) {
    header("Location: login.php");
    exit();
}

/* APENAS ADMIN */
if ($_SESSION["perfil"] != "admin") {
    header("Location: dashboard.php");
    exit();
}

/* =========================================
   CRIAR UTILIZADOR
========================================= */

$msg = "";
$mostrarForm = false;

if (isset($_POST["criar"])) {

    $mostrarForm = true;

    $utilizador = trim($_POST["utilizador"]);
    $email      = trim($_POST["email"]);
    $senha      = password_hash($_POST["senha"], PASSWORD_DEFAULT);
    $perfil     = $_POST["perfil"];
    $ativo      = 1;

    if (!empty($utilizador) && !empty($email) && !empty($_POST["senha"])) {

        /* VERIFICAR EMAIL */
        $check = $conn->prepare("
            SELECT id
            FROM utilizadores
            WHERE email = ?
        ");

        $check->bind_param("s", $email);
        $check->execute();

        $resultadoCheck = $check->get_result();

        if ($resultadoCheck->num_rows > 0) {

            $msg = "Este email já existe!";

        } else {

            $stmt = $conn->prepare("
                INSERT INTO utilizadores
                (utilizador, email, password, perfil, ativo)
                VALUES (?, ?, ?, ?, ?)
            ");

            $stmt->bind_param(
                "ssssi",
                $utilizador,
                $email,
                $senha,
                $perfil,
                $ativo
            );

            if ($stmt->execute()) {

                $msg = "Utilizador criado com sucesso!";
                $mostrarForm = false;

            } else {

                $msg = "Erro ao criar utilizador!";
            }
        }

    } else {

        $msg = "Preencha todos os campos!";
    }
}

/* =========================================
   LISTAR UTILIZADORES
========================================= */

$sql = "
SELECT
    id,
    utilizador,
    email,
    perfil,
    ativo,
    ultimo_login
FROM utilizadores
ORDER BY id DESC
";

$resultado = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="pt">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Utilizadores - IGNISSHIELD</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>

/* =========================================
   BASE
========================================= */

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial, Helvetica, sans-serif;
}

body{
    display:flex;
    background:#0d0d0d;
    color:white;
    min-height:100vh;
}

/* =========================================
   SIDEBAR
========================================= */

.sidebar{
    width:260px;
    background:#111;
    border-right:2px solid red;
    padding:20px;
    display:flex;
    flex-direction:column;
}

.logo{
    width:180px;
    margin:0 auto 30px auto;
}

.menu-title{
    color:#777;
    margin-bottom:15px;
    font-size:14px;
    text-transform:uppercase;
}

.menu{
    list-style:none;
}

.menu li{
    margin-bottom:10px;
}

.menu a{
    display:flex;
    align-items:center;
    gap:15px;
    text-decoration:none;
    color:white;
    padding:14px;
    border-radius:12px;
    background:#1a1a1a;
    transition:0.3s;
}

.menu a:hover{
    background:red;
    transform:translateX(5px);
}

/* MENU ATIVO */

.menu a.active{
    background:red;
}

/* =========================================
   MAIN
========================================= */

.main{
    flex:1;
    padding:30px;
}

/* TOPO */

.topbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:25px;
}

.topbar h1{
    font-size:32px;
}

.user{
    background:#1a1a1a;
    padding:12px 18px;
    border-radius:12px;
    border:1px solid #333;
}

/* =========================================
   ALERTA
========================================= */

.alert{
    background:#1f1f1f;
    border-left:5px solid red;
    padding:15px;
    margin-bottom:20px;
    border-radius:10px;
}

/* =========================================
   BOTÃO
========================================= */

.btn-add{
    background:red;
    color:white;
    padding:14px 20px;
    border:none;
    border-radius:14px;
    font-size:18px;
    font-weight:bold;
    cursor:pointer;
    margin-bottom:25px;
    transition:0.3s;
}

.btn-add:hover{
    background:#cc0000;
}

/* =========================================
   FORMULÁRIO
========================================= */

.form-box{
    background:#161616;
    padding:25px;
    border-radius:16px;
    margin-bottom:25px;
    display:none;
    border:1px solid #333;
}

.form-box.active{
    display:block;
}

.form-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:20px;
}

.form-group{
    display:flex;
    flex-direction:column;
}

.form-group label{
    margin-bottom:8px;
    color:#ccc;
}

.form-group input,
.form-group select{
    background:#222;
    border:1px solid #333;
    color:white;
    padding:14px;
    border-radius:10px;
    outline:none;
}

.form-group input:focus,
.form-group select:focus{
    border-color:red;
}

.full{
    grid-column:1 / -1;
}

.btn-save{
    width:100%;
    background:red;
    border:none;
    color:white;
    padding:14px 20px;
    border-radius:10px;
    font-size:16px;
    cursor:pointer;
    font-weight:bold;
}

.btn-save:hover{
    background:#cc0000;
}

/* =========================================
   TABELA
========================================= */

table{
    width:100%;
    border-collapse:collapse;
    background:#161616;
    border-radius:15px;
    overflow:hidden;
}

th{
    background:red;
    padding:15px;
    text-align:left;
}

td{
    padding:15px;
    border-bottom:1px solid #333;
}

/* =========================================
   STATUS
========================================= */

.status{
    padding:5px 10px;
    border-radius:8px;
    font-size:13px;
}

.ativo{
    background:#003300;
    color:#00ff00;
}

.inativo{
    background:#330000;
    color:#ff4d4d;
}

/* =========================================
   RESPONSIVO
========================================= */

@media(max-width:900px){

    body{
        flex-direction:column;
    }

    .sidebar{
        width:100%;
    }

    .form-grid{
        grid-template-columns:1fr;
    }

    table{
        display:block;
        overflow-x:auto;
        white-space:nowrap;
    }
}

</style>

</head>

<body>

<!-- =========================================
     SIDEBAR
========================================= -->

<div class="sidebar">

    <img src="logo.png" class="logo" alt="Logo">

    <div class="menu-title">Menu</div>

    <ul class="menu">

        <!-- DASHBOARD -->
        <li>
            <a href="dashboard.php">
                <i class="fa-solid fa-gauge"></i>
                <span>Dashboard</span>
            </a>
        </li>

        <!-- SENSORES -->
        <li>
            <a href="#">
                <i class="fa-solid fa-fire"></i>
                <span>Sensores</span>
            </a>
        </li>

        <!-- UTILIZADORES -->
        <?php if(isset($_SESSION["perfil"]) && $_SESSION["perfil"] == "admin") { ?>

        <li>
            <a href="utilizadores.php" class="active">
                <i class="fa-solid fa-users"></i>
                <span>Utilizadores</span>
            </a>
        </li>

        <?php } ?>

        <!-- ALERTAS -->
        <li>
            <a href="#">
                <i class="fa-solid fa-triangle-exclamation"></i>
                <span>Alertas</span>
            </a>
        </li>

        <!-- LOGOUT -->
        <li>
            <a href="logout.php">
                <i class="fa-solid fa-right-from-bracket"></i>
                <span>Logout</span>
            </a>
        </li>

    </ul>

</div>

<!-- =========================================
     MAIN
========================================= -->

<div class="main">

    <!-- TOPO -->
    <div class="topbar">

        <h1>Utilizadores</h1>

        <div class="user">
            👤 <?php echo htmlspecialchars($_SESSION["utilizador"]); ?>
        </div>

    </div>

    <!-- ALERTA -->
    <?php if($msg != "") { ?>

        <div class="alert">
            <?php echo $msg; ?>
        </div>

    <?php } ?>

    <!-- BOTÃO -->
    <button class="btn-add" onclick="toggleForm()">
        <i class="fa fa-plus"></i>
        Novo Utilizador
    </button>

    <!-- FORMULÁRIO -->
    <div class="form-box <?php echo $mostrarForm ? 'active' : ''; ?>" id="formBox">

        <form method="POST">

            <div class="form-grid">

                <div class="form-group">
                    <label>Utilizador</label>
                    <input type="text" name="utilizador" required>
                </div>

                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" required>
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="senha" required>
                </div>

                <div class="form-group">

                    <label>Perfil</label>

                    <select name="perfil">

                        <option value="admin">Admin</option>
                        <option value="user">User</option>
                        <option value="tecnico">Tecnico</option>

                    </select>

                </div>

                <div class="form-group full">

                    <button type="submit"
                    name="criar"
                    class="btn-save">

                        <i class="fa fa-save"></i>
                        Criar Utilizador

                    </button>

                </div>

            </div>

        </form>

    </div>

    <!-- TABELA -->
    <table>

        <tr>
            <th>ID</th>
            <th>Utilizador</th>
            <th>Email</th>
            <th>Perfil</th>
            <th>Estado</th>
            <th>Último Login</th>
        </tr>

        <?php while($row = $resultado->fetch_assoc()) { ?>

        <tr>

            <td><?php echo $row["id"]; ?></td>

            <td>
                <?php echo htmlspecialchars($row["utilizador"]); ?>
            </td>

            <td>
                <?php echo htmlspecialchars($row["email"]); ?>
            </td>

            <td>
                <?php echo htmlspecialchars($row["perfil"]); ?>
            </td>

            <td>

                <?php if($row["ativo"] == 1){ ?>

                    <span class="status ativo">
                        Ativo
                    </span>

                <?php } else { ?>

                    <span class="status inativo">
                        Inativo
                    </span>

                <?php } ?>

            </td>

            <td>

                <?php
                echo $row["ultimo_login"]
                ? $row["ultimo_login"]
                : "Nunca";
                ?>

            </td>

        </tr>

        <?php } ?>

    </table>

</div>

<script>

function toggleForm(){

    const form = document.getElementById("formBox");
    const btn  = document.querySelector(".btn-add");

    form.classList.toggle("active");

    if(form.classList.contains("active")){

        btn.innerHTML =
        '<i class="fa fa-times"></i> Fechar';

    }else{

        btn.innerHTML =
        '<i class="fa fa-plus"></i> Novo Utilizador';

    }

}

</script>

</body>
</html>